﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What kind of temperature would you like to convert?");
            string tempType = Console.ReadLine();

            Console.WriteLine("Please enter a temperature to convert: ");
            string temperatureString = Console.ReadLine();
            int temperature = int.Parse(temperatureString);
            Console.ReadLine();
        }
        static void ConvertChoice(string tempType)
        {
                switch (tempType)
                {
                    case "farenheit":
                        Console.WriteLine("Okay, Farenheit!");
                        return;
                    case "celsius":
                        Console.WriteLine("Okay, Celsius!");
                        return;
                    default:
                        Console.WriteLine("Invalid type, please type farenheit or celsius.");
                        return;
                }
        }
        
    }
}